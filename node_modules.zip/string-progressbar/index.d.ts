declare function splitBar(total: number, current: number, size?:number, line?: string, slider?: string): Array<string>
declare function filledBar(total: number, current: number, size?:number, line?: string, slider?: string): Array<string>

export { splitBar, filledBar }
