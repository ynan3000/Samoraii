// Thank you for using quick.db!
// This is an open-sourced better-sqlite3 wrapped designed to be easy to setup & utilize.

// We have an official verified Discord!
// https://discord.gg/plexidev

module.exports = require("./src/index.js");

// Documentation:
// https://quickdb.js.org
