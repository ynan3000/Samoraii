# Contributing to prebuild

- no commits direct to master
- all commits as pull requests (one or several per PR)
- each commit solves one identifiable problem
- never merge one's own PRs, another contributor does this
